import GameModel from "../models/gameModel";
import UserModel from "../models/userModel";
import { v4 as uuidv4 } from "uuid";
import e, { RequestHandler } from "express";
import { waitingQueue, updateWaitingQueue } from "../app";
import { io as socket } from "../app";

const checkAvailability = async (user: string) => {
  const filter = waitingQueue.filter((ele: string) => ele !== user);

  if (filter.length) {
    const gameId = uuidv4();
    const isWordProposer = Math.random() >= 0.5;
    const wordProposer = isWordProposer ? user : filter[0];
    const hangman = isWordProposer ? filter[0] : user;
    const game = await GameModel.create({
      gameId,
      wordProposer,
      hangman,
      status: "ongoing",
      word: "",
      matches: [],
      mismatches: [],
      winner: "",
    });
    socket.emit(hangman, {
      type: "game-started",
      isHangman: true,
      gameId: game.gameId,
    });
    socket.emit(wordProposer, {
      type: "game-started",
      isHangman: false,
      gameId: game.gameId,
    });
    updateWaitingQueue(
      waitingQueue.filter((e: string) => e !== wordProposer || e !== hangman)
    );
    return true;
  }
  updateWaitingQueue([...waitingQueue, user]);

  return false;
};

export const startGame: RequestHandler = async (req: any, res, next) => {
  try {
    const user = req.user.username;
    if (await checkAvailability(user)) {
      return res.status(202).json({ message: "Game is started" });
    } else {
      let isStarted = false;
      setTimeout(async () => {
        if (await checkAvailability(user)) {
          isStarted = true;
        }
        if (isStarted) {
          return res.status(202).json({ message: "Game is started" });
        } else {
          updateWaitingQueue(waitingQueue.filter((e: string) => e !== user));

          return res.status(400).json({ message: "Game not started" });
        }
      }, 600000);
    }
  } catch (error) {
    next(error);
  }
};

export const enterWord: RequestHandler = async (req: any, res, next) => {
  try {
    const payload = req.body;
    const game = await GameModel.findOne({ gameId: payload.gameID });
    if (!game) {
      return res.status(404).json({ message: "Game not found" });
    }

    game.word = payload.word;
    game.save();

    socket.emit(payload.hangman, {
      type: "guess-word",
    });
    return res.status(200).json({ message: "Word set" });
  } catch (error) {
    next(error);
  }
};

export const guess: RequestHandler = async (req: any, res, next) => {
  try {
    const { gameID, letter } = req.body;
    const game = await GameModel.findOne({ gameId: gameID });
    if (!game) {
      return res.status(404).json({ message: "Game not found" });
    } else {
      if (game.word?.includes(letter)) {
        game.matches.push(letter);
        const revealedWord = game.word
          ?.split("")
          .map((char: string) => (game.matches.includes(char) ? char : "_"))
          .join("");
        if (revealedWord === game.word) {
          game.status = "end";
          game.winner = game.hangman;
          game.save();
          socket.emit(game.wordProposer as string, {
            type: "game-end",
            winner: false,
          });
          socket.emit(game.hangman, {
            type: "game-end",
            winner: true,
          });
          await UserModel.updateOne(
            { username: game.hangman },
            { $inc: { wins: +1 } }
          );
        } else {
          socket.emit(game.wordProposer as string, {
            type: "correct-guess",
            letter,
          });
          socket.emit(game.hangman, {
            type: "correct-guess",
            letter,
          });
          await UserModel.updateOne(
            { username: game.hangman },
            { $inc: { points: +1 } }
          );
        }
      } else {
        game.mismatches.push(letter);
        const numMismatches = game.mismatches.length;
        if (numMismatches < 7) {
          socket.emit(game.wordProposer as string, {
            type: "incorrect-guess",
            letter,
          });
          socket.emit(game.hangman, {
            type: "incorrect-guess",
            letter,
          });
        } else {
          game.status = "end";
          game.winner = game.wordProposer;
          game.save();
          socket.emit(game.wordProposer as string, {
            type: "game-end",
            winner: true,
          });
          await UserModel.updateOne(
            { username: game.wordProposer },
            { $inc: { wins: +1 } }
          );

          socket.emit(game.hangman, {
            type: "game-end",
            winner: false,
          });
        }
      }
    }
    game.save();
    return res.status(200).json({});
  } catch (error) {
    next(error);
  }
};

export const hint: RequestHandler = async (req: any, res, next) => {
  try {
    const { gameID, user } = req.body;
    console.log;
    const game = await GameModel.findOne({ gameId: gameID });
    if (!game) {
      return res.status(404).json({ message: "Game not found" });
    }

    if (game.status == "end") {
      return res.status(400).json({ message: "Game already finished" });
    }
    const userDoc = await UserModel.findOne({ username: user });
    if (!userDoc) {
      return res.status(404).json({ message: "User not found" });
    }
    const { points } = userDoc;
    if (points < 10) {
      return res.status(400).json({ message: "Insufficient points" });
    }
    await UserModel.updateOne({ username: user }, { $inc: { points: -10 } });

    const availableHints = game.word
      ?.split("")
      .filter(
        (char: string) =>
          !game.matches.includes(char) && !game.mismatches.includes(char)
      );
    if (availableHints && availableHints.length > 0) {
      const hint =
        availableHints[Math.floor(Math.random() * availableHints.length)];
      game.matches.push(hint);
      const revealedWord = game.word
        ?.split("")
        .map((char: string) => (game.matches.includes(char) ? char : "_"))
        .join("");
      return res.status(200).json({ hint, revealedWord });
    }
    return res.status(400).json({ message: "No hint available" });
  } catch (error) {
    next(error);
  }
};
