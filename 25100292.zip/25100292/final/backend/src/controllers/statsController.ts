


import UserModel from '../models/userModel';
import { RequestHandler } from 'express';


export const leaders:RequestHandler = async (req, res,next) => {
  
    try {
        const users = await UserModel.find({}).select('-password').sort([['wins', -1]]).limit(5);
       return res.status(200).json(users);
      } catch (err) {
        console.error(err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }
}

export const user:RequestHandler = async (req, res,next) => {
  
  try {
    const { search} = req.body
      const users = await UserModel.findOne({username:search}).select('-password');
      if (!user) {
      return res.status(404).json({ error: 'no user found' });
        
      }
     return res.status(200).json(users);
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
}
