import express from "express";
import {
    guess,
    startGame,
    hint,
    enterWord,
} from "../controllers/gameController";
import { leaders, user } from "../controllers/statsController";

import { authMiddleware } from "../middleware/authMiddleware";

const statsRoutes = express.Router();

statsRoutes.post("/leaders", leaders);
statsRoutes.post("/user", user);

export default statsRoutes;
