import express from "express";
import {  guess, startGame ,hint, enterWord} from "../controllers/gameController";

import { authMiddleware } from "../middleware/authMiddleware";

const gameRouter = express.Router();



gameRouter.post('/start',[authMiddleware()],startGame);
gameRouter.post('/guess',[authMiddleware()],guess);
gameRouter.post('/hint',[authMiddleware()],hint);
gameRouter.post('/enter-word',[authMiddleware()],enterWord);


export default gameRouter;
