import "dotenv/config";
import morgan from "morgan";
import express, { NextFunction, Request, Response } from "express";
import noteRouter from "./routes/noteRoutes";
import authRouter from "./routes/authRoutes";
import cors from "cors";
import { Server } from "socket.io";
import http from "http";
import gameRouter from "./routes/gameRoutes";
import statsRoutes from "./routes/statsRoutes";
const app = express();
import UserModel from "./models/userModel";
import GameModel from "./models/gameModel";
import { fillGuessedWord } from "./utils/commonUtils";

// Set up global state variables
let waitingQueue: string[] = [];
let guessedWord:string='';

const updateWaitingQueue = (arr: string[]) => (waitingQueue = arr);

app.use(cors());

app.use(morgan("dev"));

app.use(express.json());

app.use("/api/auth", authRouter);
app.use("/api/notes", noteRouter);
app.use("/api/game", gameRouter);
app.use("/api/stats", statsRoutes);

app.use((req, res, next) => {
  next(Error("Endpoint not found"));
});

app.use((error: unknown, req: Request, res: Response, next: NextFunction) => {
  let message = "An unknown error occurred";
  if (error instanceof Error) {
    message = error.message;
  }
  res.status(500).json({ error: message });
});

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: ["http://localhost:3001", "http://localhost:3000"],
    methods: ["GET", "POST"],
  },
});
io.on("connection", async (socket) => {
  console.log("user connected with a socket id", socket.id);
  //add custom events here
  socket.on("myEvent", (myData) => {
    console.log("Received myMessage:", myData);
  });
  // const user = await authenticateUser(socket);
  socket.on("guess", async (data) => {
    const { gameID, letter } = data;
    const game: any = await GameModel.findOne({ gameId: gameID });

    if (game.word?.includes(letter)) {
      game.matches.push(letter);
      const revealedWord = game.word
        ?.split("")
        .map((char: string) => (game.matches.includes(char) ? char : "_"))
        .join("");
      if (revealedWord === game.word) {
        game.status = "end";
        game.winner = game.hangman;
        await game.save();
        guessedWord = fillGuessedWord(game.word,guessedWord,letter)
        io.emit(game.hangman, {
          type: "correct-guess",
          letter,
          guessedWord: guessedWord
        });
        io.emit(game.wordProposer, {
          type: "correct-guess",
          letter,
          guessedWord: guessedWord
        });
        await UserModel.updateOne(
          { username: game.hangman },
          { $inc: { points: +1 } }
        );
        //tiny delay added to show the complete word to the user and then end the game
        setTimeout(() => {
          io.emit(game.wordProposer as string, {
            type: "game-end",
            winner: false,
          });
          io.emit(game.hangman, {
            type: "game-end",
            winner: true,
          });
        }, 500);
        
        await UserModel.updateOne(
          { username: game.hangman },
          { $inc: { wins: +1 } }
        );
      } else {
        guessedWord = fillGuessedWord(game.word,guessedWord,letter)
        io.emit(game.hangman, {
          type: "correct-guess",
          letter,
          guessedWord: guessedWord
        });
        io.emit(game.wordProposer, {
          type: "correct-guess",
          letter,
          guessedWord: guessedWord
        });
        
        await UserModel.updateOne(
          { username: game.hangman },
          { $inc: { points: +1 } }
        );
      }
    } else {
      game.mismatches.push(letter);
      const numMismatches = game.mismatches.length;
      if (numMismatches < 7) {
        guessedWord = fillGuessedWord(game.word,guessedWord,letter)
       
        io.emit(game.wordProposer, {
          type: "incorrect-guess",
          letter,
          guessedWord: guessedWord
        });
        io.emit(game.hangman, {
          type: "incorrect-guess",
          letter,
          guessedWord: guessedWord
        });
      } else {
        game.status = "end";
        game.winner = game.wordProposer;
        await game.save();
        io.emit(game.wordProposer, {
          type: "incorrect-guess",
          letter,
          guessedWord: guessedWord
        });
        io.emit(game.hangman, {
          type: "incorrect-guess",
          letter,
          guessedWord: guessedWord
        });
        setTimeout(async ()=>{
          io.emit(game.wordProposer as string, {
            type: "game-end",
            winner: true,
          });

          await UserModel.updateOne(
            { username: game.wordProposer },
            { $inc: { wins: +1 } }
          );
  
          io.emit(game.hangman, {
            type: "game-end",
            winner: false,
          });
        },500)
        
      }
    }

    await game.save();
  });

  socket.on("enterWord", async (data) => {
    const { gameID,  word } = data;
    const game: any = await GameModel.findOne({ gameId: gameID });

    game.word = word;
    await game.save();
    
    guessedWord = Array(word.length).fill('_').join('');

    io.emit(game.hangman, {
      type: "guess-word",
      guessedWord: guessedWord
    });
    return;
  });

  socket.on("hint", async (data) => {
    const { gameID, user, word } = data;
    const game: any = await GameModel.findOne({ gameId: gameID });

    if (game.status == "end") {
      socket.emit(user, {
        type: "error",
        message: "Game ended",
      });
      return;
    }
    const userDoc = await UserModel.findOne({ username: user });

    const { points } = userDoc as any;
    if (points < 10) {
      socket.emit(user, {
        type: "error",
        message: "Insufficient points",
      });
    }
    await UserModel.updateOne({ username: user }, { $inc: { points: -10 } });

    const availableHints = game.word
      ?.split("")
      .filter(
        (char: string) =>
          !game.matches.includes(char) && !game.mismatches.includes(char)
      );
    if (availableHints && availableHints.length > 0) {
      const hint =
        availableHints[Math.floor(Math.random() * availableHints.length)];
      game.matches.push(hint);
      const revealedWord = game.word
        ?.split("")
        .map((char: string) => (game.matches.includes(char) ? char : "_"))
        .join("");
      return socket.emit(user, {
        type: "hint",
        data: { hint, revealedWord },
      });
    }
    socket.emit(user, {
      type: "error",
      message: "No Hint available",
    });
  });
});
export { io, waitingQueue, updateWaitingQueue };
export default server;
