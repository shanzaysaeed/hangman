import { InferSchemaType, Schema, model } from "mongoose";

const gameSchema = new Schema({
    gameId: { type: String, required: true, unique: true },
    word: { type: String},
    guessedWord:{type:String},
    revealedWord: { type: String,},
    matches: { type: [String]},
    mismatches: { type: [String] },
    wordProposer: { type: String },
    hangman: { type: String, required: true },
    winner: { type: String },
    status: { type: String, required: true },
  });
  
type Game = InferSchemaType<typeof gameSchema>;

export default model<Game>("Game", gameSchema);
