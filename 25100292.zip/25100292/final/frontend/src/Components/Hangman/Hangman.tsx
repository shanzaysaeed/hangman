import React from "react";
import "./hangman_given.css";

interface HangmanProps {
  wrongCount: number;
}

// you will have to conditionally render the divs accordingly,
// and change “class” to “className”

const Hangman = ({ wrongCount }: HangmanProps) => {
  return (
    <>
      <h1>Hangman</h1>
      <div id="game">
        <div id="game">
          <div className="player">
            <div className="playerModel">
              <div
                style={{
                  display: wrongCount >= 4 ? "" : "none",
                }}
                className="head"
              ></div>
              <div
                style={{
                  display: wrongCount >= 5 ? "" : "none",
                }}
                className="body"
              ></div>
              <div
                style={{
                  display: wrongCount >= 6 ? "" : "none",
                }}
                className="foot"
              ></div>
            </div>
          </div>
          <div
            style={{ display: wrongCount >= 3 ? "" : "none" }}
            className="stang3"
          ></div>
          <div
            style={{ display: wrongCount >= 2 ? "" : "none" }}
            className="stang2"
          ></div>
          <div
            style={{ display: wrongCount >= 1 ? "" : "none" }}
            className="stang"
          ></div>
          <div className="ground"></div>
        </div>
      </div>
    </>
  );
};

export default Hangman;
