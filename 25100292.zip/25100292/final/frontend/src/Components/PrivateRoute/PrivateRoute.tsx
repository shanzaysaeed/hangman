import React from "react";
import { Navigate } from "react-router-dom";

//REFERENCE: ChatGPT
interface PrivateRouteProps {
  children: React.ReactNode;
}

const PrivateRoute: React.FC<PrivateRouteProps> = ({
  children,
}: PrivateRouteProps) => {
  const token = localStorage.getItem("token");
  const isAuthenticated = token ? true : false;

  return isAuthenticated ? (
    <React.Fragment>{children}</React.Fragment>
  ) : (
    <Navigate to="/login" replace />
  );
};

export default PrivateRoute;
