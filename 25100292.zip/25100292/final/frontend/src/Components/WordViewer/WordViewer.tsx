import React, { useEffect } from "react";

interface WordViewerProps {
  word: string;
}

const WordViewer = (props: WordViewerProps) => {
  const splitWord = props.word.split("");

  useEffect(() => {
    console.log("GGGL: ", splitWord);
  }, []);

  return (
    <div
      style={{
        width: "100%",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {splitWord.map((letter, index) => {
        return (
          <span
            key={index}
            style={{
              fontSize: "30px",
              marginLeft: "4px",
              marginRight: "4px",
            }}
          >
            {letter}
          </span>
        );
      })}
    </div>
  );
};

export default WordViewer;
