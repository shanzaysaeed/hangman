import { Link, Outlet, useNavigate } from "react-router-dom";
import { useContext } from "react";
import styles from "./Navbar.module.css";

import { ScoreContext } from "../../Context/ScoreContext";

const Navbar = () => {
  const isLoggedIn = localStorage.getItem("token");
  const navigate = useNavigate();

  const { score } = useContext(ScoreContext);

  const logoutHandler = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("gameID");
    localStorage.removeItem("wordToGuess");
    localStorage.removeItem("role");
    navigate("login");
  };
  return (
    <>
      <div className={styles.linkContainer}>
        {isLoggedIn ? (
          <>
            <Link className={styles.navLink} to="/">
              Home
            </Link>
            <Link className={styles.navLink} to="/leaderboard">
              Leaderboard
            </Link>
            <p
              style={{ padding: 0, margin: 0 }}
              onClick={logoutHandler}
              className={styles.navLink}
            >
              Signout
            </p>
            <p
              style={{ padding: 0, margin: 0 }}
              onClick={logoutHandler}
              className={styles.navLink}
            >
              Current Points: {score}
            </p>
          </>
        ) : (
          <>
            <Link className={styles.navLink} to="login">
              Login
            </Link>
            <Link className={styles.navLink} to="signup">
              Signup
            </Link>
          </>
        )}
      </div>
      <Outlet />
    </>
  );
};

export default Navbar;
