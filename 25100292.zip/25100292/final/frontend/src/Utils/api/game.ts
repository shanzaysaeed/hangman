import axios from "axios";
import { BASE_URL } from "./config";



const api = axios.create({
    baseURL: BASE_URL,
});



const getConfig = () => {
    const token = localStorage.getItem('token')
    return {
        headers: {
            'Content-Type': 'application/json;charset=UTF-8',
            "Access-Control-Allow-Origin": "*",
             'Authorization': 'bearer '+token
        }
      };
}

export const startGame = async () => {
    const config = getConfig()
    const response = await api.post("/api/game/start", {},config);
    return response;
};

export const guess = async (username: string) => {
    const response = await api.post("/api/game/guess", {});
    return response;
};
export const hint = async (username: string) => {
    const response = await api.post("/api/game/hint", {});
    return response;
};
export const enterWord = async (username: string) => {
    const response = await api.post("/api/game/enter-word", {});
    return response;
};
