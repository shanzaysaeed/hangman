import axios from "axios";
import { BASE_URL } from "./config";

const api = axios.create({
    baseURL: BASE_URL,
});

export const getLeaders = async () => {
    const response = await api.post("/api/stats/leaders", {});
    return response;
};

export const getUserStats = async (search: string) => {
    const response = await api.post("/api/stats/user", {
        search,
    });
    return response;
};
