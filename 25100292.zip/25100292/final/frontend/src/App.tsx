import React from "react";
import { Route, Routes } from "react-router-dom";
import "./App.css";
import Home from "./Pages/Home/Home";
import Game from "./Pages/Game/Game";
import Login from "./Pages/Login/Login";
import Signup from "./Pages/Signup/Signup";
import Navbar from "./Components/Navbar/Navbar";
import PageNotFound from "./Pages/PageNotFound/PageNotFound";
import PrivateRoute from "./Components/PrivateRoute/PrivateRoute";
import Leaderboard from "./Pages/Leaderboard/Leaderboard";

import { io } from "socket.io-client";
const socket = io("http://localhost:3300", { transports: ["websocket"] });
socket.connect();

function App() {
  return (
    <div className="App">
      <Routes>
        <Route
          path="/game"
          element={
            <PrivateRoute>
              <Game socket={socket} />
            </PrivateRoute>
          }
        />
        <Route path="/" element={<Navbar />}>
          <Route
            index
            element={
              <PrivateRoute>
                <Home socket={socket} />
              </PrivateRoute>
            }
          />
          <Route
            path="leaderboard"
            element={
              <PrivateRoute>
                <Leaderboard />
              </PrivateRoute>
            }
          />
          <Route path="login" element={<Login />} />
          <Route path="signup" element={<Signup />} />
          <Route path="*" element={<PageNotFound />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
