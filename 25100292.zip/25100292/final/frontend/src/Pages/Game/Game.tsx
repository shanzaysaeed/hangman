import { useState, useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";
import Popup from "reactjs-popup";
import Hangman from "../../Components/Hangman/Hangman";
import Keyboard from "../../Components/Keyboard/Keyboard";
import WordViewer from "../../Components/WordViewer/WordViewer";
import { io } from "socket.io-client";
import { BASE_URL } from "../../Utils/api/config";
import { ScoreContext } from "../../Context/ScoreContext";
import { Socket } from "socket.io-client";
import { DefaultEventsMap } from "socket.io/dist/typed-events";
import { getUserStats } from "../../Utils/api/stats";

const socket = io(BASE_URL);

interface GamePageProps {
  socket: Socket<DefaultEventsMap, DefaultEventsMap>;
}

const Game = ({ socket }: GamePageProps) => {
  const [clickedLetters, setClickedLetters] = useState<string[]>([]);
  const [guessedWord, setGuessedWord] = useState<string>("");
  const [wrongCount, setWrongCount] = useState<number>(0);
  const [gameWinner, setGameWinner] = useState<string>("");
  const navigate = useNavigate();

  const { score, setScore, username } = useContext(ScoreContext);

  useEffect(() => {
    socket.on(username, (data) => {
      if (data.type === "guess-word") {
        setGuessedWord(data.guessedWord);
      } else if (data.type === "correct-guess") {
        setClickedLetters((prev) => [...prev, data.letter]);
        setGuessedWord(data.guessedWord);
      } else if (data.type === "incorrect-guess") {
        setClickedLetters((prev) => [...prev, data.letter]);
        setGuessedWord(data.guessedWord);
        setWrongCount((prev) => prev + 1);
      } else if (data.type === "game-end") {
        const role = localStorage.getItem("role");
        const opponentRole = role === "guesser" ? "proposer" : "guesser";
        setGameWinner(`${data.winner ? role : opponentRole}`);

        getUserStats(username)
          .then((resp) => {
            setScore(resp.data.points);
          })
          .catch((err) => {
            console.log("ERROR: ", err);
          });
      }
    });
  }, []);

  const letterClickHandler = (letterChosen: string) => {
    const gameID = localStorage.getItem("gameID");
    socket.emit("guess", {
      gameID: gameID,
      letter: letterChosen,
    });
  };

  return (
    <>
      <Popup
        open={!guessedWord && localStorage.getItem("role") !== "proposer"}
        overlayStyle={{ background: "rgba(0,0,0,0.5)" }}
        contentStyle={{
          background: "white",
          width: "200px",
          textAlign: "center",
        }}
        closeOnEscape={false}
        closeOnDocumentClick={false}
      >
        <p>Waiting for the word proposer to decide a word</p>
      </Popup>
      <Popup
        open={!!gameWinner}
        overlayStyle={{ background: "rgba(0,0,0,0.5)" }}
        contentStyle={{
          background: "white",
          width: "200px",
          textAlign: "center",
        }}
        closeOnEscape={false}
        closeOnDocumentClick={false}
      >
        <p>{`${gameWinner} has won the game!`}</p>
        <button
          onClick={() => {
            navigate("/");
          }}
        >
          Click here to go to home page
        </button>
      </Popup>
      <div
        style={{
          height: "80vh",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Hangman wrongCount={wrongCount} />
        <WordViewer word={guessedWord} />
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            width: "50%",
            justifyContent: "space-evenly",
            marginTop: "40px",
          }}
        >
          <p style={{ fontSize: "20px" }}>{`Last guess by the user: ${
            clickedLetters.length
              ? clickedLetters[clickedLetters.length - 1]
              : "none"
          }`}</p>
          <p style={{ fontSize: "20px" }}>{`Wrong count: ${wrongCount}`}</p>
        </div>

        {localStorage.getItem("role") === "guesser" && (
          <Keyboard
            word={guessedWord}
            clickedLetters={clickedLetters}
            letterClickHandler={letterClickHandler}
          />
        )}
      </div>
    </>
  );
};

export default Game;
