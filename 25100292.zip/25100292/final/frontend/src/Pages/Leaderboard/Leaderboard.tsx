import React, { useEffect, useState } from "react";
import { getUserStats, getLeaders } from "../../Utils/api/stats";

function Leaderboard() {
  const [leaders, setLeaders] = useState<any>([]);
  const [searchedLeader, setSearchedLeader] = useState<any>();

  const usernameChangeHandler = (event: any) => {
    const username = event.target.value;

    getUserStats(username)
      .then((resp) => {
        resp ? setSearchedLeader(resp.data) : setSearchedLeader(undefined);
      })
      .catch((err) => {
        console.log("ERROR: ", err);
      });
  };

  useEffect(() => {
    getLeaders()
      .then((resp) => {
        setLeaders(resp.data);
      })
      .catch((err) => {
        console.log("ERROR: ", err);
      });
  }, []);

  return (
    <>
      <h1>Leaderboard</h1>
      {leaders.map((leader: any) => {
        return (
          <div style={{ border: "2px solid black" }}>
            <h3>{`USERNAME: ${leader.username}`}</h3>
            <div style={{ display: "flex" }}>
              <h5 style={{ margin: "4px" }}>{`WINS: ${leader.wins}`}</h5>
              <h5 style={{ margin: "4px" }}>{`POINTS: ${leader.points}`}</h5>
            </div>
          </div>
        );
      })}

      <h1>Search Leaderboard</h1>
      <input
        type="string"
        placeholder="Username"
        onChange={usernameChangeHandler}
      />
      {searchedLeader ? (
        <div style={{ border: "2px solid black" }}>
          <h3>{`USERNAME: ${searchedLeader.username}`}</h3>
          <div style={{ display: "flex" }}>
            <h5 style={{ margin: "4px" }}>{`WINS: ${searchedLeader.wins}`}</h5>
            <h5
              style={{ margin: "4px" }}
            >{`POINTS: ${searchedLeader.points}`}</h5>
          </div>
        </div>
      ) : (
        <p>No search results! </p>
      )}
    </>
  );
}

export default Leaderboard;
