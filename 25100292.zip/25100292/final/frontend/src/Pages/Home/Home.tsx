import { useNavigate } from "react-router-dom";
import { Socket } from "socket.io-client";
import { DefaultEventsMap } from "socket.io/dist/typed-events";
import { startGame } from "../../Utils/api/game";
import { useEffect, useContext, useState } from "react";
import { ScoreContext } from "../../Context/ScoreContext";
import { getUserStats } from "../../Utils/api/stats";

interface HomePageProps {
  socket: Socket<DefaultEventsMap, DefaultEventsMap>;
}

const Home = ({ socket }: HomePageProps) => {
  const navigate = useNavigate();
  const { username, setScore } = useContext(ScoreContext);
  const [status, setStatus] = useState<string>("");

  const startClickHandler = () => {
    setStatus("Waiting for another player to join...");
    startGame();
  };

  useEffect(() => {
    getUserStats(username)
      .then((resp) => {
        setScore(resp.data.points);
      })
      .catch((err) => {
        console.log("ERROR: ", err);
      });

    socket.on(username, (data) => {
      if (data.type === "game-started") {
        localStorage.setItem("gameID", data.gameId);
        if (data.isHangman) {
          localStorage.setItem("role", "guesser");
          setStatus("You are the word guesser! Waiting for game to begin.");
        } else {
          localStorage.setItem("role", "proposer");
          setStatus("You are the word proposer! Waiting for game to begin.");
          const wordToGuess = prompt(
            "You are the word proposer. Enter the word: "
          );
          localStorage.setItem("wordToGuess", wordToGuess!);
          socket.emit("enterWord", { gameID: data.gameId, word: wordToGuess });
        }
        navigate("/game");
      }
    });
  }, []);

  return (
    <>
      <h2>Home Page</h2>
      {status ? (
        <h2>{status}</h2>
      ) : (
        <button onClick={startClickHandler}>Start Game</button>
      )}
    </>
  );
};

export default Home;
