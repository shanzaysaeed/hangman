import React, { createContext, useState } from "react";

interface ScoreContextType {
    score: number;
    setScore: React.Dispatch<React.SetStateAction<number>>;
    username: string;
    setUsername: React.Dispatch<React.SetStateAction<string>>;
}

export const ScoreContext = createContext<ScoreContextType>({
    score: 0,
    setScore: () => {},
    username: "",
    setUsername: () => {},
});

const ScoreContextProvider: React.FC<React.PropsWithChildren<{}>> = (
    props: any
) => {
    const [score, setScore] = useState<number>(0);
    const [username, setUsername] = useState<string>("");

    return (
        <ScoreContext.Provider
            value={{ score, setScore, username, setUsername }}
        >
            {props.children}
        </ScoreContext.Provider>
    );
};

export default ScoreContextProvider;
